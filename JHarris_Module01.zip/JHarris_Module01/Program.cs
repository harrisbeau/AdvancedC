﻿/*
 * James Harris 
 * Module 01
 * 8/20/18  
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Module01GettingStarted
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello world.");
            Console.ReadLine();
        }
    }
}
