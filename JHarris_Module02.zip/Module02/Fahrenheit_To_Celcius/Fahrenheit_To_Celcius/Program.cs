﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

//James Harris
//August 31
//Fahreheit to Celsius 
namespace Fahrenheit_To_Celcius
{
    class Program
    {
        static void Main(string[] args)
        {
            int deg_f = 0;
            float deg_c = 0;
          

            Console.WriteLine("Enter current degrees Fahrenheit: ");
            deg_f = Convert.ToInt32(Console.ReadLine());

            deg_c = ((deg_f - 32) * ((float)5 / (float)9));
      

            Console.WriteLine(deg_f + " degrees Fahrenheit is equal to " + deg_c + " degrees Celcius.");
            Console.ReadLine();
        }
    }
}
