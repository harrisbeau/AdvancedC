﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

//James Harris
//August 31, 2018 
//Module 02 Kilometers Conversion 

namespace Kilometers_Conversion
{
    class Program
    {
        static void Main(string[] args)
        {
            double total_miles = 0;
            double kilometer_conversion = 1.6;

            Console.WriteLine("Enter number of miles to convert: ");
            total_miles = Convert.ToDouble(Console.ReadLine());

            Console.WriteLine("");
            Console.WriteLine(total_miles + " miles is equal to " + (total_miles * kilometer_conversion) + " kilometers.");
            Console.ReadLine();


        }
    }
}
