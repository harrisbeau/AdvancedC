﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

//James Harris
//8/31/18
//Car Rental 
namespace Car_Rental
{
    class Program
    {
        static void Main(string[] args)
        {
            int daily_fee = 20;
            double mile_fee = 0.25;

            Console.WriteLine("How many days would you like to rent the car?");
            int num_days = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("How many miles did you drive during your trip?");
            double num_miles = Convert.ToDouble(Console.ReadLine());

            double total_cost = (num_days * daily_fee) + (mile_fee * num_miles);
            Console.WriteLine("The total cost of your trip is $" + total_cost);

            Console.ReadLine();

        }
    }
}
